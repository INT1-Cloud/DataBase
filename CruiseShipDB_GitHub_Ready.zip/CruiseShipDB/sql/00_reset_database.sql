-- OPTIONAL / DESTRUCTIVE: Execute only if you want to erase CruiseShipDB.
-- Run this script independently while connected to the master database.
USE master;

IF DB_ID('CruiseShipDB') IS NOT NULL
BEGIN
    ALTER DATABASE CruiseShipDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE CruiseShipDB;
END;
