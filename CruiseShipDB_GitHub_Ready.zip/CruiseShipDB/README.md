# CruiseShipDB — SQL Server Database Project

A team-friendly Microsoft SQL Server (T-SQL) course project modeling cruise ports, voyages, cabins, passengers, crew, and activities.

## Project files

| File | Purpose |
|---|---|
| [`sql/00_reset_database.sql`](sql/00_reset_database.sql) | **Optional and destructive**: deletes an existing `CruiseShipDB` |
| [`sql/01_create_database.sql`](sql/01_create_database.sql) | Creates 1 MDF, 1 NDF, and 2 LDF files with size settings |
| [`sql/02_create_tables.sql`](sql/02_create_tables.sql) | Creates seven tables, constraints, and relationships |
| [`sql/03_insert_sample_data.sql`](sql/03_insert_sample_data.sql) | Inserts 90 demonstration records |
| [`sql/04_example_queries.sql`](sql/04_example_queries.sql) | Read-only queries to inspect and test the database |
| [`docs/SQL_COMMANDS.md`](docs/SQL_COMMANDS.md) | Copy/paste SQL command examples with explanations |
| [`docs/DATABASE_DESIGN.md`](docs/DATABASE_DESIGN.md) | Tables, keys, cardinalities, and two Mermaid relationship diagrams |

## Requirements
- Microsoft SQL Server and preferably SQL Server Management Studio (SSMS).
- A writable `C:\SQLData` folder **on the machine hosting SQL Server**. If your server uses a different path or OS, edit **all four** `FILENAME` values in `sql/01_create_database.sql`.
- Permission to create a database and files.
- SQL Server syntax is used. This is **not** a MySQL script.

## Quick start in SSMS (no `GO`)

1. Connect to your SQL Server instance in SSMS.
2. If you intentionally want to erase an existing copy, open `sql/00_reset_database.sql` in its **own** query window, select the `master` database, and execute it. **This permanently removes existing project data.** Skip it if starting fresh.
3. Confirm the file directory exists and is writable by SQL Server.
4. Open `sql/01_create_database.sql` in a **new query window**, select `master` from the database dropdown, and **execute this file alone**. `CREATE DATABASE` must be the only statement in its batch.
5. Open `sql/02_create_tables.sql` and execute it.
6. Open `sql/03_insert_sample_data.sql` and execute it **once** on an empty new database.
7. Open `sql/04_example_queries.sql` to check the result.

**Why separate files?** `GO` is a client-side batch separator, not a SQL statement. Since this project deliberately avoids `GO`, `CREATE DATABASE` is executed alone in a separate batch. The other scripts use `USE CruiseShipDB;` to select the database.

## Expected demo record counts

| Table | Rows |
|---|---:|
| Ports | 8 |
| Voyages | 10 |
| Cabins | 15 |
| Passengers | 15 |
| Crew | 12 |
| Activities | 10 |
| Passenger_Activities | 20 |
| **Total** | **90** |

The sample data assumes freshly created tables with generated identity keys beginning at 1. Running the seed script on pre-populated tables is **not supported**.

## Relationship summary
- `Ports` **1:M** `Voyages`
- `Voyages` **1:M** `Cabins`
- `Voyages` **1:M** `Crew`
- `Cabins` **1:M** `Passengers`
- `Passengers` **M:N** `Activities` via `Passenger_Activities`

See [database design and diagrams](docs/DATABASE_DESIGN.md) for details.

## Constraint summary
- Primary key on each of the seven tables
- Six foreign keys
- Five unique constraints
- Seven check constraints
- Four default constraints
- `NOT NULL` on mandatory fields

## Team workflow: upload to GitHub

### Option A: GitHub website
1. Create a new repository called `CruiseShipDB`.
2. Choose **Add file → Upload files** and upload the contents of this folder, retaining their directories.
3. Commit the changes.
4. Share the repository URL with teammates.

### Option B: Git command line
Run these commands from within the `CruiseShipDB` folder, after creating an empty repository in GitHub:

```bash
git init
git add .
git commit -m "Add CruiseShipDB schema, seed data, and documentation"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/CruiseShipDB.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your actual username. If the remote repo was already initialized with content, pull/reconcile before pushing.

## Safety / privacy
- All sample passenger records and emails are synthetic. **Do not commit real passports, credentials, connection strings with passwords, or actual passenger records**.
- The optional reset script destroys data. Use it only when the whole team agrees to reset a development database.
- The repository contains SQL source files, not physical MDF/LDF database files or backups.

## Scope note
This matches the original coursework schema for learning purposes. See [design limitations](docs/DATABASE_DESIGN.md#design-limitations--possible-improvements) before treating it as a production system.
